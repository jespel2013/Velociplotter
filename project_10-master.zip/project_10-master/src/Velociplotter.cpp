//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#include "Velociplotter.h"
#include <iostream>
#include <sstream>
#include <fstream>
#include <cmath>

using namespace std;

Velociplotter::Velociplotter(string inputFilePath, string outputFilePath){
    _inputFilePath = inputFilePath;
    _outputFilePath = outputFilePath;
}

void Velociplotter::Run(){
	ReadAndWrite();
}

double Velociplotter::CalculateAverageVelocities(double km, unsigned long secs) {
	return 1.0;
}
void Velociplotter::WriteToFile(std::string outputFilePath, unsigned long time, double avgVel) {
	return;
}

void Velociplotter::ReadAndWrite() {
	ifstream inFile;
	ofstream outFile;
	stringstream inStream;
	std::string type;

	unsigned long time =0;
	unsigned long minutes=0;
	unsigned long hours=0;
	unsigned long totalSecs=0;
	unsigned long lastTotalSecs=0;
	double latitude=0;
	double lastLat=0;
	double longitude=0;
	double lastLong=0;
	double lastAvgVel = 0;
	
	double minutesLocation;
	double degrees;

	double avgVel=0;
	

	unsigned int i = 1;

	std::string temp;
	
	std::string inLine;
	
	
	outFile.open(_outputFilePath);


	inFile.open(_inputFilePath);

	if (!inFile.is_open() || !outFile.is_open()) {
		cout << "Input file path is invalid" << endl;
		return;
	}


	while (!inFile.eof()) {
		getline(inFile, inLine);
		if (inLine.length() > 5) {


			for (unsigned int j = 0; j < inLine.length(); j++) {
				if (inLine[j] == ',') {
					inLine[j] = ' ';
				}
			}
			stringstream inStream;
			inStream << inLine;
			inStream >> type;

			if (type.compare("$GPGGA") == 0) {

				inStream >> time;
				if (inStream.peek() == '.') {
					inStream >> temp >> latitude >> temp >> longitude;
				}
				else {
					inStream >> latitude >> temp >> longitude;
				}
				totalSecs = 0;
				//calculate seconds
				totalSecs += (time % 100);
				minutes = (time / 100) % 100;
				totalSecs += (minutes * 60);
				hours = (time / 10000);
				totalSecs += (hours * 3600);

				//latitude
				minutesLocation = fmod(latitude, 100.0);
				degrees = (latitude - minutesLocation) / 100.0;
				latitude = degrees + (minutesLocation / 60.0);
				//longitude
				minutesLocation = fmod(longitude, 100.0);
				degrees = (longitude - minutesLocation) / 100.0;
				longitude = degrees + (minutesLocation / 60.0);


				if (i != 1) {
					if (lastTotalSecs > totalSecs) {
						outFile.close();
						outFile.clear();
						return;
					}
					if (totalSecs - lastTotalSecs > 1) {
						for (unsigned int j = 1; j <= (unsigned int)(totalSecs - lastTotalSecs); j++) {
							outFile << (lastTotalSecs + j) << " " << lastAvgVel << endl;
							/*cout << (lastTotalSecs + j) << " " << lastAvgVel << endl;*/
						}
					}

					GPSPosition tempPosition = GPSPosition(latitude, longitude, totalSecs);
					GPSPosition lastPosition = GPSPosition(lastLat, lastLong, lastTotalSecs);

					avgVel = tempPosition.CalcDistanceKmTo(lastPosition) * 3600;



					outFile << totalSecs << " " << avgVel << endl;
					/*cout<< totalSecs << " " << avgVel << endl;*/

				}


			}

			lastAvgVel = avgVel;
			lastTotalSecs = totalSecs;
			lastLong = longitude;
			lastLat = latitude;




		
		}

		i++;

	}
}
