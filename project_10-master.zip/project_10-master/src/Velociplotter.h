//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#ifndef VELOCIPLOTTER_H
#define VELOCIPLOTTER_H

#include "GPSPosition.h"
#include <string>

class Velociplotter{
private:
    std::string _inputFilePath;
    std::string _outputFilePath;
public:
    Velociplotter(std::string inputFilePath, std::string ouputFilePath);
    void Run();
    double CalculateAverageVelocities(double km, unsigned long secs);
	void WriteToFile(std::string outputFilePath, unsigned long time, double avgVel);
	void ReadAndWrite();

    
};
#endif


